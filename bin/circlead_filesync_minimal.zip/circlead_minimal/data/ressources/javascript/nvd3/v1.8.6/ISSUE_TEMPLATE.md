PLEASE READ THIS BEFORE SUBMITTING A NEW ISSUE.

ARE YOU ASKING FOR HELP? Please use Stack Overflow tag nvd3.js and include a link to a live, minimal example on jsfiddle / plunker.

The live example should use the latest code for nvd3. Links are below:
https://raw.githubusercontent.com/novus/nvd3/master/build/nv.d3.js
https://raw.githubusercontent.com/novus/nvd3/master/build/nv.d3.css

Supported D3 js version. v3.5.17

https://github.com/cdnjs/cdnjs/blob/master/ajax/libs/d3/3.5.17/d3.min.js

ARE YOU REPORTING AN ISSUE? Please provide below information with the issue:

NVD3 version used:

Browser and OS used:

Live Example: Jsfiddle / Plunker

Expected Behaviour:

Present Behaviour:

Any more information regarding the issue:
